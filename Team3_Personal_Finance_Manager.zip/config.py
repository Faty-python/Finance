smtp_server = "smtp.gmail.com"
smtp_port = 587
smtp_username = "swathikakani18560@gmail.com" 
smtp_password = "waoghsoqtoaikobc"
sender_email = "swathikakani18560@gmail.com"
