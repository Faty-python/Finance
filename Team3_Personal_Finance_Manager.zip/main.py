from app import MainApp

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
